#!/bin/bash
set -euo pipefail
campaign=<workspace>/validation79-20260917
cd "$campaign/driver"
: "${QUALIFICATION_JOURNAL_SINCE:?Set only to the recorded, approved recovery boundary}"
export LIBVA_DRIVERS_PATH="$PWD/build-hardware/src"
export LIBVA_DRIVER_NAME=v4l2_request
export V4L2R_SOURCE_COMMIT=299d29333bc215d9d045130a0e0c6b8558a6654a
python3 - <<'PY'
import hashlib, json
from pathlib import Path
r=json.loads(Path('../preparation-identity.json').read_text())
assert hashlib.sha256(Path('build-hardware/src/v4l2_request_drv_video.so').read_bytes()).hexdigest()==r['driver_sha256']
for name in ('dimensions-v2-guard.jsonl','generated-guard.jsonl','codec-guard.jsonl'):
    assert not (Path('..')/name).exists(), 'fresh evidence paths required'
PY
python3 tests/hwguard.py --identity avd --journal-since "$QUALIFICATION_JOURNAL_SINCE" \
    --deadline 120 --log "$campaign/dimensions-v2-guard.jsonl" -- \
    sh tests/dimension-hardware.sh "$LIBVA_DRIVERS_PATH" "$campaign/dimensions-v2" \
    > "$campaign/dimensions-v2.log" 2>&1
python3 tests/hwguard.py --identity avd --journal-since "$QUALIFICATION_JOURNAL_SINCE" \
    --deadline 600 --log "$campaign/generated-guard.jsonl" -- \
    bash -c 'set -e; sh tests/shared-contexts.sh "$LIBVA_DRIVERS_PATH"; sh tests/h264-high10.sh "$LIBVA_DRIVERS_PATH"; sh tests/vp9-matrix.sh "$LIBVA_DRIVERS_PATH"; sh tests/frame-check.sh "$LIBVA_DRIVERS_PATH"' \
    > "$campaign/generated.log" 2>&1
python3 tests/hwguard.py --identity avd --journal-since "$QUALIFICATION_JOURNAL_SINCE" \
    --deadline 900 --log "$campaign/codec-guard.jsonl" -- \
    python3 "$campaign/codec-suites.py" > "$campaign/codec-suites.log" 2>&1
