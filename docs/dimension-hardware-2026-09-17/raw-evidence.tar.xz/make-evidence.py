import hashlib, io, json, re, subprocess, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'driver'
DEST = REPO / 'docs/dimension-hardware-2026-09-17'
BASE = '299d29333bc215d9d045130a0e0c6b8558a6654a'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]

def guarded(name):
    records = rows(ROOT / (name + '-guard.jsonl'))
    end = records[-1]
    assert end['event'] == 'final' and end['status'] == 'ok' and end['returncode'] == 0
    assert end['idle'] and not end['holders'] and not end['timed_out'] and not end['wedged'] and not end['abort_reason']
    return records

def main():
    identity = json.loads((ROOT / 'preparation-identity.json').read_text())
    recovery = json.loads((ROOT / 'authorized-recovery.json').read_text())
    assert identity['source_commit'] == BASE
    assert sha((REPO / 'build-hardware/src/v4l2_request_drv_video.so').read_bytes()) == identity['driver_sha256']
    assert subprocess.check_output(['git', 'diff', BASE, '--', 'src'], cwd=REPO) == b''
    dimensions = rows(ROOT / 'dimensions-v2/results.jsonl')
    assert len(dimensions) == 31 and dimensions[-1]['passed']
    assert dimensions[-1]['control_submissions'] == dimensions[-1]['request_queues'] == 0
    generated = (ROOT / 'generated.log').read_text()
    shared = sum(map(int, re.findall(r'Shared VA display, (?:normal|early): four streams, (\d+) frames', generated)))
    high10 = sum(map(int, re.findall(r'High 10 .*?: (\d+) frames, identical pixels', generated)))
    vp9 = sum(map(int, re.findall(r'VP9 depth=.*?: (\d+) frames, identical pixels', generated)))
    assert (shared, high10, vp9) == (336, 144, 384)
    assert 'Native-size hashing: resolution change and crop match; truncated input fails.' in generated
    assert 'ALL EXACT R11 PASS SETS MATCH' in (ROOT / 'codec-suites.log').read_text()
    comparisons = {}
    for key in ('hevc','avc','frext','vp9','vp9-high10','overrides'):
        comp = json.loads((ROOT / 'codec-suites' / (key + '-comparison.json')).read_text())
        summary = json.loads((ROOT / 'codec-suites' / key / 'summary.json').read_text())
        assert not comp['lost'] and not comp['gained'] and summary['complete']
        comparisons[key] = dict(comp, passing_frames=summary['passing_frames'],
                                high10=summary['high10'], profile_mismatch=summary['profile_mismatch'],
                                subset=summary['subset'])
        strict = ROOT / 'codec-suites' / (key + '-strict-comparison.json')
        if strict.exists(): comparisons[key]['strict_comparison'] = json.loads(strict.read_text())
    guards = {n: guarded(n) for n in ('dimensions-v2', 'generated', 'codec')}
    report = {
        'issue':'https://github.com/iconidentify/libva-v4l2_request/issues/79',
        'companion_parent':'https://github.com/iconidentify/omarchy-m1-video/issues/12',
        'date':'2026-09-17', 'tested_source_commit':BASE,
        'production_src_tree':identity['source_tree'], 'driver_sha256':identity['driver_sha256'],
        'kernel':identity['kernel'], 'packages':identity['packages'],
        'hardware':'Apple M1 T8103 / apple,avd; /dev/video0 and /dev/media0',
        'recovery':recovery, 'offline_release_tests':identity['offline_release_tests'],
        'dimensions':dimensions, 'guarded_results':guards,
        'generated':{'shared_context_hardware_frames':shared,'high10_hardware_frames':high10,
                     'vp9_hardware_frames':vp9,'total_hardware_frame_comparisons':shared+high10+vp9,
                     'native_size_crop_and_truncation_checks':'passed'},
        'conformance':comparisons,
        'failed_probe':{'directory':'dimensions','reason':'Harness counted two initialization control-capability probes as admission submissions. Corrected counter baseline after driver initialization; the failed run is retained. The driver rejected 8x8 before context setup, and the guard ended idle without a decoder fault.'},
        'review':'Maintainer implementation and self-review of the hardware probe/evidence; not independent review. PR #80 separately records independent review of its contributor implementation.',
        'limits':[
            'The size probe observes and forwards ioctls unchanged; accepted parameter/context sizes are not claimed as decoded frames.',
            'The AVD 64..4096 contract is a current kernel/userspace boundary, not proof of the firmware minimum.',
            'Full codec checks use the uninstrumented selected driver. Known failing vectors and any non-green fallback verdict are retained.',
            'VP9 high-depth coverage is one selected 10-bit 4:2:0 vector; five high-depth suite entries remain outside this hardware qualification.',
            'The five H.264 profile-override vectors are an explicit subset and do not increase the default AVC total.',
            'The pre-session decoder timeout remains unexplained. User authorized one existing-module unload/reload after saving work; no automatic retry, reboot, installation or kernel edit occurred.',
            'The recorded module file hash identifies the file selected for the authorized reload, not a measured in-memory module hash.',
            'No codec support count, package pin, client/display behaviour or boot stability is promoted. The one-hour resource campaign remains separate #41 work.'
        ]
    }
    DEST.mkdir(exist_ok=False)
    candidates=[]
    for name in ('authorized-recovery.json','preparation-identity.json','corpus-identities.json',
                 'preflight-full-boot.jsonl','preflight-after-apps-closed.jsonl','release-build-tests.log',
                 'dimensions.log','dimensions-guard.jsonl','dimensions-v2.log','dimensions-v2-guard.jsonl',
                 'generated.log','generated-guard.jsonl','codec-suites.log','codec-guard.jsonl',
                 'run-hardware.sh','codec-suites.py','make-evidence.py'):
        candidates.append(ROOT/name)
    for name in ('dimensions','dimensions-v2','codec-suites'):
        candidates.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and
                          (p.suffix in ('.json','.jsonl','.log','.frames','.sha256','.stderr')))
    members={}
    archive=DEST/'raw-evidence.tar.xz'
    with tarfile.open(archive,'w:xz',preset=6) as tar:
        for p in sorted(set(candidates)):
            raw=p.read_bytes(); public=raw.replace(b'<workspace>',b'<workspace>')
            name=str(p.relative_to(ROOT))
            members[name]={'raw_sha256':sha(raw),'public_sha256':sha(public),'bytes':len(public)}
            entry=tarfile.TarInfo(name); entry.size=len(public); entry.mode=0o644; entry.mtime=1789603200
            tar.addfile(entry,io.BytesIO(public))
    (DEST/'archive-manifest.json').write_text(json.dumps(members,indent=2)+'\n')
    report['archive']={'path':'raw-evidence.tar.xz','sha256':sha(archive.read_bytes()),'members':len(members),
                       'redaction':'Only the maintainer home-directory prefix is replaced with <workspace> in public text; both original and public member hashes are recorded. No media, executable binaries or core dump is included.'}
    (DEST/'validation.json').write_text(json.dumps(report,indent=2).replace('<workspace>','<workspace>')+'\n')
    with tarfile.open(archive,'r:xz') as tar:
        assert len(tar.getmembers())==len(members)
        for entry in tar:
            assert entry.isfile() and sha(tar.extractfile(entry).read())==members[entry.name]['public_sha256']
    print(json.dumps({'archive_bytes':archive.stat().st_size,'members':len(members),'report':str(DEST/'validation.json')}))

if __name__=='__main__': main()
