"""Run the pinned complete suites and preserve known failures, not only totals."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent / 'driver'
driver = root / 'build-hardware/src'
output = root.parent / 'codec-suites'
fluster = Path('<workspace>/src/fluster')
assert os.environ.get('LIBVA_HW_GUARD_LEASE'), 'hardware guard required'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=fluster,
                               text=True).strip() == 'f3ad284a9e6cac70dc01b02e0de71c2994181d34'
output.mkdir(exist_ok=False)
baseline = json.loads((root / 'docs/r11-pass-sets.json').read_text())['suites']
items = [('hevc', 'h.265/JCT-VC-HEVC_V1.json'),
         ('avc', 'h.264/JVT-AVC_V1.json'),
         ('frext', 'h.264/JVT-FR-EXT.json'),
         ('vp9', 'vp9/VP9-TEST-VECTORS.json'),
         ('vp9-high10', 'vp9/VP9-TEST-VECTORS-HIGH.json'),
         ('overrides', 'h.264/JVT-AVC_V1.json')]
for name, suite in items:
    definition = fluster / 'test_suites' / suite
    env = dict(os.environ, LIBVA_V4L2_DIAG='json')
    if baseline[name]['high10'] == 'off':
        env.pop('LIBVA_V4L2_H264_HIGH10', None)
    else:
        env['LIBVA_V4L2_H264_HIGH10'] = baseline[name]['high10']
    cmd = ['python3', 'tests/conformance.py', str(definition),
           str(fluster / 'resources'), '--driver', str(driver),
           '--output', str(output / name), '--timeout', '45']
    if name in ('vp9-high10', 'overrides'):
        cmd += ['--vectors', *baseline[name]['passing_vectors']]
    if baseline[name]['profile_mismatch']:
        cmd.append('--profile-mismatch')
    print('START', name, flush=True)
    result = subprocess.run(cmd, cwd=root, env=env)
    if result.returncode not in (0, 1):
        raise SystemExit(result.returncode)
    summary = json.loads((output / name / 'summary.json').read_text())
    assert summary['complete'], summary
    rows = [json.loads(line) for line in (output / name / 'results.jsonl').read_text().splitlines()]
    actual = {r['vector'] for r in rows if r.get('event') == 'result' and r['success']}
    expected = set(baseline[name]['passing_vectors'])
    comparison = {'suite': name, 'passed': len(actual), 'total': summary['total'],
                  'baseline_total': baseline[name]['total'],
                  'lost': sorted(expected - actual), 'gained': sorted(actual - expected),
                  'suite_definition_sha256': hashlib.sha256(definition.read_bytes()).hexdigest()}
    (output / f'{name}-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
    print('COMPARE', json.dumps(comparison), flush=True)
    if actual != expected:
        raise SystemExit('passing vector sets changed; stop and investigate')
    if name in ('hevc', 'avc', 'frext', 'vp9'):
        result = subprocess.run(['python3', 'tests/compare-results.py', '--baseline',
                                 'docs/r11-pass-sets.json', '--candidate',
                                 str(output / name / 'summary.json'), '--suite', name],
                                cwd=root, capture_output=True, text=True)
        (output / f'{name}-strict-comparison.json').write_text(result.stdout)
        (output / f'{name}-strict-comparison.stderr').write_text(result.stderr)
        strict = json.loads(result.stdout)
        if not strict['ok']:
            # This existing non-green fallback verdict is preserved explicitly.
            expected_error = ['software fallback cannot produce a green hardware result: FM1_FT_E']
            assert name == 'avc' and strict['errors'] == expected_error, strict
            assert not any(strict[k] for k in ('lost_passes', 'new_passes', 'missing_vectors', 'extra_vectors'))
            print('KNOWN NON-GREEN AVC FALLBACK VERDICT:', json.dumps(strict), flush=True)
print('ALL EXACT R11 PASS SETS MATCH', flush=True)
